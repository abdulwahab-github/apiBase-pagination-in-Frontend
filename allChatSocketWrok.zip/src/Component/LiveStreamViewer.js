import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';

// Initialize socket connection
const socket = io('http://192.168.18.125:3000/');

const LiveStreamViewer = ({ streamId, no }) => {
  const [viewerCount, setViewerCount] = useState(0);
  const [viewers, setViewers] = useState([]);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [auctionDuration, setAuctionDuration] = useState();
  const [setDuration, setSetDuration] = useState(''); // State for setting auction duration
  const userId = localStorage.getItem('user');

  useEffect(() => {
    if (!userId || !streamId) return;

    // Clear previous stream's comments and auction duration when streamId changes
    setComments([]);
    setAuctionDuration(0);

    // Emit events to join the stream
    socket.emit('authenticate', userId);
    socket.emit('joinStream', { streamId, userId });

    const handleViewerCountUpdate = ({ streamId: id, count }) => {
      if (id === streamId) {
        setViewerCount(count);
      }
    };

    const handleViewerDetailsUpdate = ({ streamId: id, viewers }) => {
      if (id === streamId) {
        setViewers(viewers);
      }
    };

    const handleCommentUpdate = ({ streamId: id, comment }) => {
      if (id === streamId) {
        setComments((prevComments) => [...prevComments, comment]);
      }
    };

    const handleAuctionCountdownUpdate = ({ streamId: id, duration }) => {
      if (id === streamId) {
        setAuctionDuration(duration);
      }
    };

    socket.on('viewerCountUpdate', handleViewerCountUpdate);
    socket.on('viewerDetailsUpdate', handleViewerDetailsUpdate);
    socket.on('commentUpdate', handleCommentUpdate);
    socket.on('auctionCountdownUpdate', handleAuctionCountdownUpdate);

    const handleBeforeUnload = () => {
      socket.emit('leaveStream', { streamId, userId });
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      socket.emit('leaveStream', { streamId, userId });
      window.removeEventListener('beforeunload', handleBeforeUnload);
      socket.off('viewerCountUpdate', handleViewerCountUpdate);
      socket.off('viewerDetailsUpdate', handleViewerDetailsUpdate);
      socket.off('commentUpdate', handleCommentUpdate);
      socket.off('auctionCountdownUpdate', handleAuctionCountdownUpdate);
    };
  }, [userId, streamId]);

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    if (newComment.trim()) {
      socket.emit('newComment', { streamId, userId, comment: newComment });
      setNewComment('');
    }
  };

  const handleSetAuctionDuration = (e) => {
    e.preventDefault();
    console.log(setDuration, "setDuration");
    
    // Emit the duration correctly
    socket.emit('setAuctionDuration', { streamId, duration: setDuration });
    setSetDuration(''); // Clear input after submitting
  };
  const formatDuration = (durationInSeconds) => {
    const minutes = Math.floor(durationInSeconds / 60);
    const seconds = durationInSeconds % 60;
  
    // Pad with leading zeros if necessary
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };
  
  return (
    <div>
      <h1>Live Stream no {no}</h1>
      <p>Current viewers: {viewerCount}</p>
      <p>Auction Duration: {formatDuration(auctionDuration || 0)} seconds</p>

      {/* Set Auction Duration Input */}
      <form onSubmit={handleSetAuctionDuration}>
        <input
          type="text"
          value={setDuration}
          onChange={(e) => setSetDuration(e.target.value)}
          placeholder="Set auction duration (e.g., '4 hours 30 mins')"
        />
        <button type="submit">Set Duration</button>
      </form>
      <ul>
        {viewers.length > 0 ? (
          viewers.map(viewer => (
            <li key={viewer.userId}>
              <img
                style={{ borderRadius: '50px' }}
                src={`https://backend.iimiin.com/uploads/${viewer.image}`}
                alt={viewer.name}
                width="50"
                height="50"
              />
              <span style={{ padding: '0px 10px' }}>{viewer.name}</span>
              <button>{viewer?.isFollowed ? "message" : "follow"}</button>
            </li>
          ))
        ) : (
          <p>No viewers to display</p>
        )}
      </ul>
      <div style={{ marginTop: '20px' }}>
        <h3>Comments</h3>
        <ul>
          {comments.length > 0 ? (
            comments.map((comment, index) => (
              <li key={index} style={{ marginBottom: '10px' }}>
                <img
                  style={{ borderRadius: '50px' }}
                  src={`https://backend.iimiin.com/uploads/${comment.image}`}
                  alt={comment.name}
                  width="30"
                  height="30"
                />
                <span style={{ padding: '0px 10px', fontWeight: 'bold' }}>{comment.name}:</span>
                <span>{comment.comment}</span>
              </li>
            ))
          ) : (
            <p>No comments yet.</p>
          )}
        </ul>
      </div>

      <form onSubmit={handleCommentSubmit}>
        <input
          type="text"
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          placeholder="Type your comment..."
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
};

export default LiveStreamViewer;