// import logo from './logo.svg';
// import './App.css';
// import AppRouter  from './Config/Router';
// import { useState } from 'react';
// import MessageComponent from './Component/Chat';
// import ChatList from './Component/ChatList';
// function App() {
//   const [val ,setval] = useState('')
//   const [no ,setno] = useState(0)
//   const reciverId = localStorage.getItem('user')
//   const sendId = localStorage.getItem('user')
//   return (
//     // <div className="App">
//     //   <button onClick={()=>{
//     //     setval("66eaafb1ca3feccd190e394e")
//     //     setno(1)
//     //     }}>STream 1</button>
//     //   <button onClick={()=>{setval("66ebeafb528ee09489b5dc0e")
//     //     setno(2)}}>STream 2</button>
    
//     //   {/* <Practice/> */}
//     //   <LiveStreamViewer streamId={val}no={no}/>
//     // </div>
//     <>
//     <MessageComponent senderId={'6685102e794d3e2ffdc9e696'}  receiverId={"66c367b9f112e084be5b23e6"}/>
//     <ChatList/>
//     {/* <MessageComponent senderId={'66c367b9f112e084be5b23e6'}  receiverId={"6685102e794d3e2ffdc9e696"}/> */}
//     </>
//   );
// }

// export default App;



import React, { useState } from "react";
import UserList from "./Component/UserList";
import Chat from "./Component/Chat";

const App = () => {
  const [selectedUser, setSelectedUser] = useState(null);
  const userId = localStorage.getItem("user"); // Assuming this holds the logged-in user's ID

  return (
    // <div style={{ display: "flex", height: "100vh" }}>
    //   <UserList onSelectUser={setSelectedUser} />
    //   {selectedUser && <Chat selectedUser={selectedUser} userId={userId} />}
    // </div>
    <UserList onSelectUser={setSelectedUser} userId={userId}/>
  );
};

export default App;
